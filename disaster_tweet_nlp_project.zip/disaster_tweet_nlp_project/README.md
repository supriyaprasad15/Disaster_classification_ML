# Disaster Tweet Classification (NLP)

This project classifies a tweet as disaster-related (`1`) or not disaster-related (`0`) using TF-IDF features and machine-learning models. It also includes exploratory data analysis and a small Flask web interface.

## Dataset

Put the provided Excel file in `data/` and name it `twitter_disaster.xlsx`.

Expected columns from the supplied file:
- `id`
- `keyword`
- `location`
- `text`
- `target` (`0` = non-disaster, `1` = disaster)

The uploaded dataset contains **7,613 rows and 5 columns**, not 10,000 rows as mentioned in the project brief. The code reads the actual file and prints its dimensions.

## Setup

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Copy the supplied Excel file into `data/twitter_disaster.xlsx`.

## 1. Train and evaluate

```bash
python train_model.py
```

The script:
- checks the dataset columns and missing values
- plots the target distribution and frequent terms
- splits data into train/test sets with stratification
- trains and compares Logistic Regression and Multinomial Naive Bayes using TF-IDF
- prints accuracy, precision, recall, F1, and a classification report
- saves a confusion matrix, ROC curve, precision-recall curve, and metrics CSV
- saves the best model to `artifacts/disaster_tweet_model.joblib`

The model selection is based on test-set F1 for a starter project. For a more rigorous comparison, select models using cross-validation on training data and reserve the test set for final evaluation.

## 2. Run the web application

After training completes:

```bash
python app.py
```

Open `http://127.0.0.1:5000` in your browser and paste a tweet.

## Notes

- This is an educational prototype, not an emergency alert system. Predictions can be wrong and should not be used as the sole basis for emergency decisions.
- The model uses TF-IDF and word/character n-grams. It does not use pretrained Word2Vec/GloVe embeddings or sentiment analysis; those are optional extensions in the project brief.
- Keep `id`, `keyword`, and `location` out of the text model by default to avoid relying on metadata rather than tweet content.
