from pathlib import Path
import re
import html
import joblib
from flask import Flask, render_template, request

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "artifacts" / "disaster_tweet_model.joblib"

app = Flask(__name__)
model = joblib.load(MODEL_PATH) if MODEL_PATH.exists() else None

def clean_tweet(text):
    text = html.unescape(str(text))
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"@\w+", " ", text)
    return re.sub(r"\s+", " ", text).strip()

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    confidence = None
    tweet = ""
    error = None

    if request.method == "POST":
        tweet = request.form.get("tweet", "").strip()
        if not tweet:
            error = "Please enter a tweet first."
        elif model is None:
            error = "Model not found. Run `python train_model.py` first."
        else:
            cleaned = clean_tweet(tweet)
            prediction = int(model.predict([cleaned])[0])
            result = "Disaster-related tweet" if prediction == 1 else "Non-disaster tweet"
            if hasattr(model, "predict_proba"):
                confidence = round(float(max(model.predict_proba([cleaned])[0])) * 100, 1)

    return render_template("index.html", result=result, confidence=confidence,
                           tweet=tweet, error=error)

if __name__ == "__main__":
    app.run(debug=True)
