from pathlib import Path
import re
import html
import json
import warnings

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, confusion_matrix, ConfusionMatrixDisplay,
    roc_curve, auc, precision_recall_curve, average_precision_score
)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore", category=UserWarning)

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "twitter_disaster.xlsx"
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "reports"
ARTIFACTS.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)

def clean_tweet(text):
    """Basic normalization; keep words and hashtags, remove URLs and HTML."""
    text = html.unescape(str(text))
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"@\w+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_PATH}\n"
            "Place the provided Excel file at data/twitter_disaster.xlsx."
        )
    df = pd.read_excel(DATA_PATH)
    required = {"text", "target"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    df = df.dropna(subset=["text", "target"]).copy()
    df["target"] = pd.to_numeric(df["target"], errors="coerce")
    df = df.dropna(subset=["target"])
    df["target"] = df["target"].astype(int)
    df = df[df["target"].isin([0, 1])]
    df["clean_text"] = df["text"].map(clean_tweet)
    return df

def save_eda(df):
    # Target distribution
    counts = df["target"].value_counts().sort_index()
    plt.figure(figsize=(6, 4))
    sns.barplot(x=counts.index.astype(str), y=counts.values)
    plt.title("Tweet Class Distribution (0 = Non-disaster, 1 = Disaster)")
    plt.xlabel("Target")
    plt.ylabel("Number of tweets")
    plt.tight_layout()
    plt.savefig(REPORTS / "class_distribution.png", dpi=150)
    plt.close()

    # Most frequent words, separately for each class
    from sklearn.feature_extraction.text import CountVectorizer
    for label, label_name in [(0, "non_disaster"), (1, "disaster")]:
        texts = df.loc[df["target"] == label, "clean_text"]
        if texts.empty:
            continue
        vectorizer = CountVectorizer(stop_words="english", max_features=20,
                                     ngram_range=(1, 2), min_df=2)
        matrix = vectorizer.fit_transform(texts)
        totals = matrix.sum(axis=0).A1
        terms = pd.DataFrame({"term": vectorizer.get_feature_names_out(),
                              "count": totals}).sort_values("count", ascending=False)
        terms.to_csv(REPORTS / f"top_terms_{label_name}.csv", index=False)
        plt.figure(figsize=(9, 6))
        plot_data = terms.head(15).sort_values("count")
        plt.barh(plot_data["term"], plot_data["count"])
        plt.title(f"Frequent Terms: {label_name.replace('_', ' ').title()}")
        plt.xlabel("Count")
        plt.tight_layout()
        plt.savefig(REPORTS / f"top_terms_{label_name}.png", dpi=150)
        plt.close()

def build_pipeline(classifier):
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            lowercase=True,
            strip_accents="unicode",
            sublinear_tf=True,
            ngram_range=(1, 2),
            min_df=2,
            max_features=100_000,
            token_pattern=r"(?u)\b\w\w+\b"
        )),
        ("classifier", classifier)
    ])

def main():
    df = load_data()
    print("\n=== Dataset overview ===")
    print(f"Rows after basic cleaning: {len(df):,}")
    print("\nColumns and data types:")
    print(df.dtypes)
    print("\nMissing values:")
    print(df[["text", "target"]].isna().sum())
    print("\nClass counts:")
    print(df["target"].value_counts().sort_index().rename(index={
        0: "0 = non-disaster", 1: "1 = disaster"
    }))

    save_eda(df)
    X = df["clean_text"]
    y = df["target"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    models = {
        "Logistic Regression": build_pipeline(
            LogisticRegression(max_iter=1500, class_weight="balanced", C=2.0)
        ),
        "Multinomial Naive Bayes": build_pipeline(
            MultinomialNB(alpha=0.5)
        ),
    }

    rows = []
    fitted = {}
    for name, model in models.items():
        print(f"\n=== Training: {name} ===")
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        scores = {
            "model": name,
            "accuracy": accuracy_score(y_test, pred),
            "precision": precision_score(y_test, pred, zero_division=0),
            "recall": recall_score(y_test, pred, zero_division=0),
            "f1": f1_score(y_test, pred, zero_division=0),
        }
        rows.append(scores)
        fitted[name] = model
        print(json.dumps(scores, indent=2))
        print(classification_report(y_test, pred, zero_division=0))

    metrics = pd.DataFrame(rows).sort_values("f1", ascending=False)
    metrics.to_csv(REPORTS / "model_metrics.csv", index=False)
    best_name = metrics.iloc[0]["model"]
    best_model = fitted[best_name]
    best_pred = best_model.predict(X_test)
    print(f"\nSelected model by test F1: {best_name}")
    print("\nConfusion matrix (rows=actual, columns=predicted):")
    print(confusion_matrix(y_test, best_pred))

    ConfusionMatrixDisplay.from_predictions(
        y_test, best_pred, display_labels=["Non-disaster", "Disaster"],
        cmap="Blues", values_format="d"
    )
    plt.title(f"Confusion Matrix — {best_name}")
    plt.tight_layout()
    plt.savefig(REPORTS / "confusion_matrix.png", dpi=150)
    plt.close()

    # Both supplied classifiers support predict_proba.
    prob = best_model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, prob)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(f"ROC Curve — {best_name}")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(REPORTS / "roc_curve.png", dpi=150)
    plt.close()

    precision, recall, _ = precision_recall_curve(y_test, prob)
    ap = average_precision_score(y_test, prob)
    plt.figure(figsize=(6, 5))
    plt.plot(recall, precision, label=f"Average precision = {ap:.3f}")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title(f"Precision-Recall Curve — {best_name}")
    plt.legend(loc="lower left")
    plt.tight_layout()
    plt.savefig(REPORTS / "precision_recall_curve.png", dpi=150)
    plt.close()

    joblib.dump(best_model, ARTIFACTS / "disaster_tweet_model.joblib")
    with open(ARTIFACTS / "model_info.json", "w", encoding="utf-8") as f:
        json.dump({"model": best_name, "positive_label": 1,
                   "negative_label": 0, "roc_auc": roc_auc,
                   "average_precision": ap}, f, indent=2)
    print(f"\nSaved model: {ARTIFACTS / 'disaster_tweet_model.joblib'}")
    print(f"Saved reports to: {REPORTS}")

if __name__ == "__main__":
    main()
